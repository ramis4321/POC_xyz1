﻿using System;

namespace POC.API
{
    internal class NotFoundException : ApplicationException
    {
    }
}