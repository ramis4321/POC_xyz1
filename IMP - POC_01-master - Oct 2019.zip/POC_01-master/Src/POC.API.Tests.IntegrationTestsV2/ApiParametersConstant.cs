﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POC.API.Tests.IntegrationTestsV2
{
    public static class ApiParametersConstant
    {
        public static readonly string ApiToken = "api-key-token";
    }
}
