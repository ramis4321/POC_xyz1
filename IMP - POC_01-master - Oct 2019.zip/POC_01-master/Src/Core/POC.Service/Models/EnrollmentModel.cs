﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POC.Service.Models
{
    class EnrollmentModel
    {
    }
}
