﻿using System;

namespace POC.Service
{
    public class Class1
    {
    }
}
