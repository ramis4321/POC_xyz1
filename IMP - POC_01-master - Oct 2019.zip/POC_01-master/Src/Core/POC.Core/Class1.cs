﻿using System;

namespace POC.Core
{
    public class Class1
    {
    }
}
