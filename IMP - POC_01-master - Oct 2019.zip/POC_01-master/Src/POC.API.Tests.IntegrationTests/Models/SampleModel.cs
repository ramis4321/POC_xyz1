﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POC.API.Tests.IntegrationTests.Models
{
    //We reuse most of the models from Web Api project 
    class SampleModel
    {
    }
}
