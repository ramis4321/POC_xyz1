﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureWebApp.Models
{
    public class Fruit
    {
        public int FruitID { get; set; }
        public string FruitName { get; set; }
        public string Color { get; set; }
        public string EntryTime { get; set; }

    }
}
